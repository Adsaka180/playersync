package com.groove.player

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

object SecureSpaceManager {

    private const val PREFS_NAME        = "secure_space_prefs"
    private const val KEY_PIN_HASH      = "pin_hash"
    private const val KEY_SALT          = "pin_salt"
    private const val KEY_APPS          = "secure_apps"
    private const val KEY_IS_SETUP      = "is_setup"
    private const val KEY_LOCK_THEME    = "lock_theme"
    private const val KEY_BIOMETRIC     = "biometric_enabled"
    private const val KEY_HINT          = "pin_hint"
    private const val KEY_FAKE_PIN      = "fake_pin_hash"
    private const val KEY_FAKE_APPS     = "fake_apps"   // apps shown when fake PIN used

    // ── PIN management ────────────────────────────────────────────────────────

    fun isSetup(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_IS_SETUP, false)
    }

    fun setupPin(context: Context, pin: String, hint: String = "") {
        val salt = generateSalt()
        val hash = hashPin(pin, salt)
        prefs(context).edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_SALT, salt)
            .putString(KEY_HINT, hint)
            .putBoolean(KEY_IS_SETUP, true)
            .apply()
    }

    fun setupFakePin(context: Context, fakePin: String) {
        val salt = prefs(context).getString(KEY_SALT, generateSalt()) ?: generateSalt()
        val hash = hashPin(fakePin, salt)
        prefs(context).edit().putString(KEY_FAKE_PIN, hash).apply()
    }

    fun verifyPin(context: Context, pin: String): PinResult {
        val prefs = prefs(context)
        val salt  = prefs.getString(KEY_SALT, "") ?: ""
        val hash  = prefs.getString(KEY_PIN_HASH, "") ?: ""
        val fakeHash = prefs.getString(KEY_FAKE_PIN, "") ?: ""
        val input = hashPin(pin, salt)
        return when {
            input == hash     -> PinResult.CORRECT
            input == fakeHash -> PinResult.FAKE
            else              -> PinResult.WRONG
        }
    }

    fun changePin(context: Context, oldPin: String, newPin: String): Boolean {
        if (verifyPin(context, oldPin) != PinResult.CORRECT) return false
        setupPin(context, newPin, getHint(context))
        return true
    }

    fun resetSecureSpace(context: Context) {
        prefs(context).edit().clear().apply()
    }

    fun getHint(context: Context): String {
        return prefs(context).getString(KEY_HINT, "") ?: ""
    }

    fun isBiometricEnabled(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_BIOMETRIC, false)
    }

    fun setBiometricEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_BIOMETRIC, enabled).apply()
    }

    // ── App management ────────────────────────────────────────────────────────

    fun addApp(context: Context, packageName: String) {
        val apps = getApps(context).toMutableSet()
        apps.add(packageName)
        prefs(context).edit().putStringSet(KEY_APPS, apps).apply()
    }

    fun removeApp(context: Context, packageName: String) {
        val apps = getApps(context).toMutableSet()
        apps.remove(packageName)
        prefs(context).edit().putStringSet(KEY_APPS, apps).apply()
    }

    fun getApps(context: Context): Set<String> {
        return prefs(context).getStringSet(KEY_APPS, emptySet()) ?: emptySet()
    }

    fun isAppInSecureSpace(context: Context, packageName: String): Boolean {
        return getApps(context).contains(packageName)
    }

    // Fake PIN shows a decoy set of apps (privacy feature)
    fun getFakeApps(context: Context): Set<String> {
        return prefs(context).getStringSet(KEY_FAKE_APPS, emptySet()) ?: emptySet()
    }

    fun setFakeApps(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(KEY_FAKE_APPS, packages).apply()
    }

    // ── Theme ─────────────────────────────────────────────────────────────────

    enum class LockTheme(val label: String) {
        DARK("Sombre"),
        PURPLE("Violet"),
        TEAL("Bleu-vert"),
        MINIMAL("Minimaliste")
    }

    fun getLockTheme(context: Context): LockTheme {
        val name = prefs(context).getString(KEY_LOCK_THEME, LockTheme.DARK.name) ?: LockTheme.DARK.name
        return LockTheme.valueOf(name)
    }

    fun setLockTheme(context: Context, theme: LockTheme) {
        prefs(context).edit().putString(KEY_LOCK_THEME, theme.name).apply()
    }

    // ── Crypto helpers ────────────────────────────────────────────────────────

    private fun generateSalt(): String {
        val bytes = ByteArray(16)
        java.security.SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hashPin(pin: String, salt: String): String {
        val input = "$salt:$pin"
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    enum class PinResult { CORRECT, FAKE, WRONG }
}
