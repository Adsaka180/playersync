package com.groove.player

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.groove.player.databinding.ActivityPermissionsBinding

class PermissionsActivity : AppCompatActivity() {

    companion object {
        const val REQUEST_ADMIN = 1001
    }

    private lateinit var binding: ActivityPermissionsBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        updatePermissionUI(results)
        updateButtonState()
    }

    private val manageStorageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            binding.itemStorage.setGranted(Environment.isExternalStorageManager())
        }
        updateButtonState()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        checkCurrentPermissions()
    }

    private fun setupUI() {
        // Permissions standard
        binding.btnGrantAll.setOnClickListener {
            permissionLauncher.launch(MainActivity.REQUIRED_PERMISSIONS)
        }

        // Activer mode admin système
        binding.btnGrantAdmin.setOnClickListener {
            DeviceAdminManager.requestAdminPrivileges(this, REQUEST_ADMIN)
        }

        // Gérer les apps admin (notre liste interne)
        binding.btnManageAdminApps.setOnClickListener {
            startActivity(Intent(this, AdminAppsActivity::class.java))
        }

        // Continuer
        binding.btnContinue.setOnClickListener {
            startActivity(Intent(this, AppListActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh quand on revient de AdminAppsActivity
        checkCurrentPermissions()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ADMIN) {
            val isAdmin = DeviceAdminManager.isAdminActive(this)
            binding.itemAdmin.setGranted(isAdmin)
            if (isAdmin) {
                Toast.makeText(this, "Droits administrateur accordés ✓", Toast.LENGTH_SHORT).show()
            }
            updateButtonState()
        }
    }

    private fun checkCurrentPermissions() {
        val locationOk = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        binding.itemLocation.setGranted(locationOk)

        val bluetoothOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
        }
        binding.itemBluetooth.setGranted(bluetoothOk)

        val storageOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        binding.itemStorage.setGranted(storageOk)

        val installOk = packageManager.canRequestPackageInstalls()
        binding.itemInstall.setGranted(installOk)

        val notifOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
        binding.itemNotifications.setGranted(notifOk)

        val adminOk = DeviceAdminManager.isAdminActive(this)
        binding.itemAdmin.setGranted(adminOk)

        updateButtonState()
    }

    private fun updatePermissionUI(results: Map<String, Boolean>) {
        results.forEach { (perm, granted) ->
            when {
                perm.contains("LOCATION")     -> binding.itemLocation.setGranted(granted)
                perm.contains("BLUETOOTH")    -> binding.itemBluetooth.setGranted(granted)
                perm.contains("STORAGE")      -> binding.itemStorage.setGranted(granted)
                perm.contains("NOTIFICATION") -> binding.itemNotifications.setGranted(granted)
            }
        }
    }

    private fun updateButtonState() {
        val criticalOk = binding.itemLocation.isGranted() && binding.itemStorage.isGranted()
        binding.btnContinue.isEnabled = criticalOk
        binding.btnContinue.alpha = if (criticalOk) 1f else 0.4f

        val adminOk = DeviceAdminManager.isAdminActive(this)
        binding.btnGrantAdmin.text = if (adminOk) "✓ Administrateur actif" else "Activer mode Administrateur"
        binding.btnGrantAdmin.alpha = if (adminOk) 0.5f else 1f
        binding.btnGrantAdmin.isEnabled = !adminOk
    }
}
