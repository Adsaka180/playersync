package com.groove.player

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

object DeviceAdminManager {

    fun getAdminComponent(context: Context): ComponentName {
        return ComponentName(context, AppDeviceAdminReceiver::class.java)
    }

    fun isAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(getAdminComponent(context))
    }

    /** Lance l'écran système de demande d'administration */
    fun requestAdminPrivileges(context: android.app.Activity, requestCode: Int) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, getAdminComponent(context))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "AppTransfer a besoin des droits Administrateur pour :\n\n" +
                "• Désinstaller automatiquement les apps après transfert\n" +
                "• Gérer les packages en arrière-plan\n" +
                "• Garantir un transfert complet sans intervention manuelle\n\n" +
                "Ces droits ne seront jamais utilisés à distance."
            )
        }
        context.startActivityForResult(intent, requestCode)
    }

    /** Retire les droits admin (nécessaire avant désinstallation de l'app) */
    fun removeAdmin(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.removeActiveAdmin(getAdminComponent(context))
    }

    /**
     * Désinstalle un package silencieusement si on est admin.
     * Sinon, ouvre l'intent système classique avec confirmation.
     */
    fun uninstallPackage(context: Context, packageName: String): Boolean {
        return if (isAdminActive(context)) {
            try {
                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                // Sur Android 9+ avec Device Owner on peut silent-uninstall
                // Sinon on utilise l'intent standard
                val intent = Intent(Intent.ACTION_DELETE).apply {
                    data = android.net.Uri.fromParts("package", packageName, null)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                true
            } catch (e: Exception) {
                false
            }
        } else {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = android.net.Uri.fromParts("package", packageName, null)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            false
        }
    }
}
