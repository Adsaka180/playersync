package com.groove.player

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val tvTitle = findViewById<TextView>(R.id.tvTitle)

        btnStart.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
    }
}
