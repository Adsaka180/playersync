package com.groove.player

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.groove.player.databinding.ActivitySecureSpaceBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SecureSpaceActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySecureSpaceBinding
    private val secureApps = mutableListOf<AppInfo>()
    private val filteredApps = mutableListOf<AppInfo>()
    private lateinit var adapter: SecureAppAdapter
    private var fakeMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If not unlocked, redirect to PIN screen
        if (!intent.getBooleanExtra("unlocked", false)) {
            if (!SecureSpaceManager.isSetup(this)) {
                startActivity(Intent(this, SetupPinActivity::class.java))
            } else {
                startActivity(Intent(this, PinUnlockActivity::class.java))
            }
            finish()
            return
        }

        fakeMode = intent.getBooleanExtra("fake_mode", false)
        binding = ActivitySecureSpaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        loadSecureApps()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnSettings.setOnClickListener { showSettingsMenu() }
        binding.btnAddApp.setOnClickListener { openAddAppPicker() }
        binding.btnLock.setOnClickListener {
            finish() // Lock = just close, next open requires PIN
        }

        binding.tvSpaceName.text = if (fakeMode) "Espace Perso" else "Espace Sécurisé"
        binding.tvLockStatus.text = if (fakeMode) "Mode discret actif" else "Protégé par code"

        binding.searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterApps(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        adapter = SecureAppAdapter(filteredApps,
            onLaunch = { app -> launchApp(app) },
            onRemove = { app -> confirmRemoveApp(app) }
        )
        binding.recyclerSecure.layoutManager = GridLayoutManager(this, 3)
        binding.recyclerSecure.adapter = adapter
    }

    private fun loadSecureApps() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerSecure.visibility = View.GONE
        binding.layoutEmpty.visibility = View.GONE

        CoroutineScope(Dispatchers.IO).launch {
            val pm = packageManager
            val packageSet = if (fakeMode) {
                SecureSpaceManager.getFakeApps(this@SecureSpaceActivity)
            } else {
                SecureSpaceManager.getApps(this@SecureSpaceActivity)
            }

            val apps = packageSet.mapNotNull { pkg ->
                try {
                    val info = pm.getApplicationInfo(pkg, 0)
                    AppInfo(
                        packageName = pkg,
                        appName = pm.getApplicationLabel(info).toString(),
                        icon = pm.getApplicationIcon(info),
                        apkPath = info.sourceDir,
                        sizeMb = java.io.File(info.sourceDir).length() / (1024f * 1024f),
                        isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                } catch (e: Exception) { null }
            }.sortedBy { it.appName }

            withContext(Dispatchers.Main) {
                secureApps.clear()
                secureApps.addAll(apps)
                filterApps(binding.searchField.text?.toString() ?: "")
                binding.progressBar.visibility = View.GONE

                if (apps.isEmpty()) {
                    binding.layoutEmpty.visibility = View.VISIBLE
                    binding.recyclerSecure.visibility = View.GONE
                } else {
                    binding.recyclerSecure.visibility = View.VISIBLE
                    binding.layoutEmpty.visibility = View.GONE
                }

                binding.tvAppCount.text = "${apps.size} application${if (apps.size > 1) "s" else ""}"
            }
        }
    }

    private fun filterApps(query: String) {
        filteredApps.clear()
        filteredApps.addAll(
            if (query.isEmpty()) secureApps
            else secureApps.filter {
                it.appName.contains(query, ignoreCase = true) ||
                it.packageName.contains(query, ignoreCase = true)
            }
        )
        adapter.notifyDataSetChanged()
    }

    private fun launchApp(app: AppInfo) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Impossible de lancer ${app.appName}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmRemoveApp(app: AppInfo) {
        AlertDialog.Builder(this)
            .setTitle("Retirer de l'Espace Sécurisé")
            .setMessage("Retirer ${app.appName} de l'Espace Sécurisé ?\n\nL'application restera installée sur votre téléphone.")
            .setPositiveButton("Retirer") { _, _ ->
                SecureSpaceManager.removeApp(this, app.packageName)
                secureApps.remove(app)
                filterApps(binding.searchField.text?.toString() ?: "")
                if (secureApps.isEmpty()) {
                    binding.layoutEmpty.visibility = View.VISIBLE
                    binding.recyclerSecure.visibility = View.GONE
                }
                binding.tvAppCount.text = "${secureApps.size} application${if (secureApps.size > 1) "s" else ""}"
                Toast.makeText(this, "${app.appName} retiré", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun openAddAppPicker() {
        startActivityForResult(
            Intent(this, AddToSecureSpaceActivity::class.java),
            REQUEST_ADD_APP
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ADD_APP && resultCode == RESULT_OK) {
            loadSecureApps()
        }
    }

    private fun showSettingsMenu() {
        val items = arrayOf(
            "Changer le code PIN",
            "Activer empreinte digitale",
            "Thème du verrou",
            "Code PIN factice (discrétion)",
            "Réinitialiser l'Espace Sécurisé"
        )
        AlertDialog.Builder(this)
            .setTitle("Paramètres Espace Sécurisé")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, SetupPinActivity::class.java).apply {
                        putExtra("mode", "change")
                    })
                    1 -> toggleBiometric()
                    2 -> showThemePicker()
                    3 -> showFakePinSetup()
                    4 -> confirmReset()
                }
            }
            .show()
    }

    private fun toggleBiometric() {
        val current = SecureSpaceManager.isBiometricEnabled(this)
        SecureSpaceManager.setBiometricEnabled(this, !current)
        Toast.makeText(
            this,
            if (!current) "Empreinte activée" else "Empreinte désactivée",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showThemePicker() {
        val themes = SecureSpaceManager.LockTheme.values()
        val labels = themes.map { it.label }.toTypedArray()
        val current = SecureSpaceManager.getLockTheme(this)
        AlertDialog.Builder(this)
            .setTitle("Thème du verrou")
            .setSingleChoiceItems(labels, themes.indexOf(current)) { dialog, which ->
                SecureSpaceManager.setLockTheme(this, themes[which])
                dialog.dismiss()
                Toast.makeText(this, "Thème : ${themes[which].label}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showFakePinSetup() {
        AlertDialog.Builder(this)
            .setTitle("Code PIN factice")
            .setMessage(
                "Le code PIN factice ouvre un Espace Sécurisé vide (ou avec des apps leurres).\n\n" +
                "Utile si quelqu'un vous force à déverrouiller votre téléphone — il verra un espace vide au lieu de vos vraies apps.\n\n" +
                "Voulez-vous configurer un code factice ?"
            )
            .setPositiveButton("Configurer") { _, _ ->
                startActivity(Intent(this, SetupPinActivity::class.java).apply {
                    putExtra("mode", "fake")
                })
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ Réinitialiser l'Espace Sécurisé")
            .setMessage("Toutes les applications seront retirées de l'Espace Sécurisé et votre code sera supprimé.\n\nCette action est irréversible.")
            .setPositiveButton("Réinitialiser") { _, _ ->
                SecureSpaceManager.resetSecureSpace(this)
                Toast.makeText(this, "Espace Sécurisé réinitialisé", Toast.LENGTH_LONG).show()
                finish()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    companion object { const val REQUEST_ADD_APP = 2001 }

    // ── Adapter ──────────────────────────────────────────────────────────────

    inner class SecureAppAdapter(
        private val apps: List<AppInfo>,
        private val onLaunch: (AppInfo) -> Unit,
        private val onRemove: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<SecureAppAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.imgSecureIcon)
            val name: TextView  = view.findViewById(R.id.tvSecureName)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_secure_app, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = apps[position]
            holder.icon.setImageDrawable(app.icon)
            holder.name.text = app.appName
            holder.itemView.setOnClickListener { onLaunch(app) }
            holder.itemView.setOnLongClickListener {
                onRemove(app)
                true
            }
        }

        override fun getItemCount() = apps.size
    }
}
