package com.groove.player

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.groove.player.databinding.ActivityMusicSettingsBinding

class MusicSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMusicSettingsBinding
    private var versionTapCount = 0
    private val resetTapHandler = Handler(Looper.getMainLooper())
    private val resetTapRunnable = Runnable { versionTapCount = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMusicSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupNormalSettings()
        setupSecretTrigger()
    }

    private fun setupNormalSettings() {
        binding.btnBack.setOnClickListener { finish() }
        binding.switchEqualizer.isChecked = true
        binding.switchCrossfade.isChecked = false
        binding.switchNormalize.isChecked = true
        binding.switchGapless.isChecked = true
        binding.switchCarMode.isChecked = false
        binding.switchEqualizer.setOnCheckedChangeListener { _, checked ->
            Toast.makeText(this, if (checked) "Égaliseur activé" else "Égaliseur désactivé", Toast.LENGTH_SHORT).show()
        }
        binding.tvQuality.setOnClickListener { showQualityPicker() }
        binding.tvThemeOption.setOnClickListener { showThemePicker() }
        binding.tvCacheSize.setOnClickListener {
            Toast.makeText(this, "Cache vidé", Toast.LENGTH_SHORT).show()
            binding.tvCacheValue.text = "0 MB"
        }
    }

    private fun setupSecretTrigger() {
        // Tap version row 7 times within 3s → open vault
        binding.tvVersionRow.setOnClickListener {
            versionTapCount++
            resetTapHandler.removeCallbacks(resetTapRunnable)
            resetTapHandler.postDelayed(resetTapRunnable, 3000)
            when (versionTapCount) {
                3 -> Toast.makeText(this, "Plus que ${7 - versionTapCount} appuis...", Toast.LENGTH_SHORT).show()
                5 -> Toast.makeText(this, "Plus que 2...", Toast.LENGTH_SHORT).show()
                6 -> Toast.makeText(this, "Encore 1...", Toast.LENGTH_SHORT).show()
                7 -> {
                    versionTapCount = 0
                    resetTapHandler.removeCallbacks(resetTapRunnable)
                    openVault()
                }
            }
        }
    }

    private fun openVault() {
        // Always go through PIN first, then to vault dashboard
        val intent = if (SecureSpaceManager.isSetup(this)) {
            Intent(this, PinUnlockActivity::class.java)
        } else {
            Intent(this, SetupPinActivity::class.java)
        }
        intent.putExtra("destination", "vault_dashboard")
        startActivity(intent)
    }

    private fun showQualityPicker() {
        val options = arrayOf("Normal (128 kbps)", "Haute qualité (320 kbps)", "Lossless (FLAC)")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Qualité audio")
            .setSingleChoiceItems(options, 1) { dialog, which ->
                binding.tvQualityValue.text = options[which].substringBefore(" (")
                dialog.dismiss()
            }.show()
    }

    private fun showThemePicker() {
        val options = arrayOf("Sombre (défaut)", "Nuit profonde", "Aube", "Forêt", "Océan")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Thème")
            .setSingleChoiceItems(options, 0) { dialog, _ -> dialog.dismiss() }.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        resetTapHandler.removeCallbacksAndMessages(null)
    }
}
