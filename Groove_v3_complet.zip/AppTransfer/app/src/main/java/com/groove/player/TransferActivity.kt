package com.groove.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.groove.player.databinding.ActivityTransferBinding

class TransferActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransferBinding
    private lateinit var wifiP2pManager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private var selectedPackages: ArrayList<String> = arrayListOf()
    private var transferMode = TransferMode.SEND
    private val deviceList = mutableListOf<WifiP2pDevice>()

    enum class TransferMode { SEND, RECEIVE }

    private val transferReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                TransferService.ACTION_PROGRESS -> {
                    val progress = intent.getIntExtra("progress", 0)
                    val appName = intent.getStringExtra("app_name") ?: ""
                    updateProgress(progress, appName)
                }
                TransferService.ACTION_COMPLETE -> {
                    val success = intent.getBooleanExtra("success", false)
                    onTransferComplete(success)
                }
                TransferService.ACTION_ERROR -> {
                    val error = intent.getStringExtra("error") ?: "Erreur inconnue"
                    showError(error)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransferBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selectedPackages = intent.getStringArrayListExtra("selected_packages") ?: arrayListOf()

        setupWifiDirect()
        setupUI()
        showModeSelection()
    }

    private fun setupWifiDirect() {
        wifiP2pManager = getSystemService(WIFI_P2P_SERVICE) as WifiP2pManager
        channel = wifiP2pManager.initialize(this, mainLooper, null)
    }

    private fun setupUI() {
        binding.btnSendMode.setOnClickListener {
            transferMode = TransferMode.SEND
            startDeviceDiscovery()
        }
        binding.btnReceiveMode.setOnClickListener {
            transferMode = TransferMode.RECEIVE
            startReceiving()
        }
        binding.btnCancel.setOnClickListener {
            stopService(Intent(this, TransferService::class.java))
            finish()
        }
    }

    private fun showModeSelection() {
        binding.layoutModeSelection.visibility = View.VISIBLE
        binding.layoutProgress.visibility = View.GONE
        binding.layoutDeviceList.visibility = View.GONE
        binding.layoutComplete.visibility = View.GONE

        if (selectedPackages.isEmpty()) {
            binding.btnSendMode.visibility = View.GONE
            binding.tvModeTitle.text = "Mode réception"
            binding.tvModeSubtitle.text = "Attendez qu'un autre appareil vous transfère des applications"
        } else {
            binding.tvSelectedCount.text = "${selectedPackages.size} application${if (selectedPackages.size > 1) "s" else ""} sélectionnée${if (selectedPackages.size > 1) "s" else ""}"
        }
    }

    private fun startDeviceDiscovery() {
        binding.layoutModeSelection.visibility = View.GONE
        binding.layoutDeviceList.visibility = View.VISIBLE
        binding.tvScanStatus.text = "Recherche d'appareils..."
        binding.progressScan.visibility = View.VISIBLE

        wifiP2pManager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                binding.tvScanStatus.text = "Scan en cours..."
                loadNearbyDevices()
            }
            override fun onFailure(reason: Int) {
                binding.tvScanStatus.text = "Erreur de scan (code $reason)\nVérifiez que le WiFi est activé"
                binding.progressScan.visibility = View.GONE
            }
        })
    }

    private fun loadNearbyDevices() {
        wifiP2pManager.requestPeers(channel) { peerList ->
            val devices = peerList.deviceList.toList()
            deviceList.clear()
            deviceList.addAll(devices)
            binding.progressScan.visibility = View.GONE

            if (devices.isEmpty()) {
                binding.tvScanStatus.text = "Aucun appareil trouvé\nAssurez-vous que l'autre téléphone exécute AppTransfer"
                binding.btnRescan.visibility = View.VISIBLE
            } else {
                binding.tvScanStatus.text = "${devices.size} appareil${if (devices.size > 1) "s" else ""} trouvé${if (devices.size > 1) "s" else ""}"
                setupDeviceAdapter(devices)
            }
        }

        binding.btnRescan.setOnClickListener { startDeviceDiscovery() }
    }

    private fun setupDeviceAdapter(devices: List<WifiP2pDevice>) {
        val names = devices.map { it.deviceName.ifEmpty { it.deviceAddress } }.toTypedArray()
        binding.listDevices.adapter = android.widget.ArrayAdapter(
            this, android.R.layout.simple_list_item_1, names
        )
        binding.listDevices.setOnItemClickListener { _, _, position, _ ->
            connectToDevice(devices[position])
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        binding.tvScanStatus.text = "Connexion à ${device.deviceName}..."
        binding.progressScan.visibility = View.VISIBLE

        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
        }

        wifiP2pManager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                wifiP2pManager.requestConnectionInfo(channel) { info ->
                    if (info.groupFormed) {
                        startTransferService(info.groupOwnerAddress.hostAddress ?: "", info.isGroupOwner)
                    }
                }
            }
            override fun onFailure(reason: Int) {
                binding.tvScanStatus.text = "Échec de connexion (code $reason)"
                binding.progressScan.visibility = View.GONE
            }
        })
    }

    private fun startReceiving() {
        binding.layoutModeSelection.visibility = View.GONE
        binding.layoutProgress.visibility = View.VISIBLE
        binding.tvTransferTitle.text = "En attente de réception..."
        binding.tvTransferSubtitle.text = "Gardez l'app ouverte sur cet appareil"
        binding.progressTransfer.isIndeterminate = true

        val serviceIntent = Intent(this, TransferService::class.java).apply {
            action = TransferService.ACTION_RECEIVE
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun startTransferService(hostAddress: String, isHost: Boolean) {
        binding.layoutDeviceList.visibility = View.GONE
        binding.layoutProgress.visibility = View.VISIBLE
        binding.tvTransferTitle.text = "Transfert en cours..."
        binding.progressTransfer.isIndeterminate = false
        binding.progressTransfer.progress = 0

        val serviceIntent = Intent(this, TransferService::class.java).apply {
            action = TransferService.ACTION_SEND
            putStringArrayListExtra("packages", selectedPackages)
            putExtra("host_address", hostAddress)
            putExtra("is_host", isHost)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun updateProgress(progress: Int, appName: String) {
        binding.progressTransfer.progress = progress
        binding.tvTransferTitle.text = "Transfert en cours... $progress%"
        binding.tvTransferSubtitle.text = appName
    }

    private fun onTransferComplete(success: Boolean) {
        binding.layoutProgress.visibility = View.GONE
        binding.layoutComplete.visibility = View.VISIBLE
        if (success) {
            binding.ivCompleteIcon.setImageResource(R.drawable.ic_check_circle)
            binding.tvCompleteTitle.text = "Transfert terminé !"
            binding.tvCompleteSubtitle.text = "${selectedPackages.size} application${if (selectedPackages.size > 1) "s ont" else " a"} été transférée${if (selectedPackages.size > 1) "s" else ""}"
            binding.btnDeleteSource.visibility = View.VISIBLE
        } else {
            binding.ivCompleteIcon.setImageResource(R.drawable.ic_error)
            binding.tvCompleteTitle.text = "Transfert échoué"
            binding.tvCompleteSubtitle.text = "Une erreur s'est produite"
            binding.btnDeleteSource.visibility = View.GONE
        }

        binding.btnDeleteSource.setOnClickListener { offerUninstall() }
        binding.btnDone.setOnClickListener { finish() }
    }

    private fun offerUninstall() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Supprimer les apps transférées ?")
            .setMessage("Voulez-vous désinstaller les ${selectedPackages.size} application${if (selectedPackages.size > 1) "s" else ""} de cet appareil maintenant qu'elles ont été transférées ?")
            .setPositiveButton("Désinstaller") { _, _ ->
                uninstallApps()
            }
            .setNegativeButton("Garder") { _, _ -> finish() }
            .show()
    }

    private fun uninstallApps() {
        selectedPackages.forEach { packageName ->
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = android.net.Uri.fromParts("package", packageName, null)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }
    }

    private fun showError(error: String) {
        binding.layoutProgress.visibility = View.GONE
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Erreur de transfert")
            .setMessage(error)
            .setPositiveButton("OK") { _, _ -> }
            .show()
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(TransferService.ACTION_PROGRESS)
            addAction(TransferService.ACTION_COMPLETE)
            addAction(TransferService.ACTION_ERROR)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(transferReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(transferReceiver)
    }

    override fun onDestroy() {
        super.onDestroy()
        wifiP2pManager.removeGroup(channel, null)
    }
}
