package com.groove.player

import android.graphics.drawable.Drawable
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val apps: MutableList<AppInfo>,
    private val onSelectionChanged: () -> Unit
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val name: TextView = view.findViewById(R.id.appName)
        val pkg: TextView = view.findViewById(R.id.appPackage)
        val size: TextView = view.findViewById(R.id.appSize)
        val checkbox: CheckBox = view.findViewById(R.id.appCheckbox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.name.text = app.name
        holder.pkg.text = app.packageName
        holder.size.text = formatSize(app.sizeBytes)
        holder.checkbox.isChecked = app.isSelected

        try {
            val icon: Drawable = holder.itemView.context.packageManager
                .getApplicationIcon(app.packageName)
            holder.icon.setImageDrawable(icon)
        } catch (e: Exception) {
            holder.icon.setImageResource(android.R.drawable.sym_def_app_icon)
        }

        holder.itemView.setOnClickListener {
            app.isSelected = !app.isSelected
            holder.checkbox.isChecked = app.isSelected
            onSelectionChanged()
        }
        holder.checkbox.setOnCheckedChangeListener { _, checked ->
            app.isSelected = checked
            onSelectionChanged()
        }
    }

    override fun getItemCount() = apps.size

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1_000_000 -> "%.1f Mo".format(bytes / 1_000_000f)
            bytes >= 1_000 -> "%.0f Ko".format(bytes / 1_000f)
            else -> "$bytes o"
        }
    }
}
