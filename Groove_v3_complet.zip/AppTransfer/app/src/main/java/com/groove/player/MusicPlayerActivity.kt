package com.groove.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.groove.player.databinding.ActivityMusicPlayerBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.Intent
import android.view.View

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri
)

class MusicPlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMusicPlayerBinding
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var isPlaying = false

    private val updateSeekBar = object : Runnable {
        override fun run() {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    binding.seekBar.progress = it.currentPosition
                    binding.tvCurrentTime.text = formatTime(it.currentPosition.toLong())
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMusicPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        loadTracks()
    }

    private fun setupButtons() {
        binding.btnPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnNext.setOnClickListener { playNext() }
        binding.btnPrev.setOnClickListener { playPrev() }
        binding.btnShuffle.setOnClickListener { toggleShuffle() }
        binding.btnRepeat.setOnClickListener { toggleRepeat() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, MusicSettingsActivity::class.java))
        }
        binding.btnLibrary.setOnClickListener {
            binding.layoutNowPlaying.visibility = View.GONE
            binding.layoutLibrary.visibility = View.VISIBLE
        }
        binding.btnNowPlaying.setOnClickListener {
            binding.layoutNowPlaying.visibility = View.VISIBLE
            binding.layoutLibrary.visibility = View.GONE
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) mediaPlayer?.seekTo(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun loadTracks() {
        CoroutineScope(Dispatchers.IO).launch {
            val loaded = mutableListOf<Track>()
            if (ContextCompat.checkSelfPermission(
                    this@MusicPlayerActivity, Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
                )
                val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
                val cursor = contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection, selection, null,
                    "${MediaStore.Audio.Media.TITLE} ASC"
                )
                cursor?.use {
                    val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    while (it.moveToNext()) {
                        val id = it.getLong(idCol)
                        loaded.add(Track(
                            id = id,
                            title = it.getString(titleCol) ?: "Titre inconnu",
                            artist = it.getString(artistCol) ?: "Artiste inconnu",
                            album = it.getString(albumCol) ?: "Album inconnu",
                            duration = it.getLong(durCol),
                            uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                        ))
                    }
                }
            }

            // Demo tracks if no real music found
            if (loaded.isEmpty()) {
                loaded.addAll(listOf(
                    Track(1, "Midnight Drive", "The Neon Waves", "Synthscape", 213000, Uri.EMPTY),
                    Track(2, "Faded Lights", "Luna Echo", "Dreamland", 187000, Uri.EMPTY),
                    Track(3, "City Rain", "Orbital Drift", "Urban Tales", 245000, Uri.EMPTY),
                    Track(4, "Northern Soul", "Astral Keys", "Polar", 198000, Uri.EMPTY),
                    Track(5, "Glass Ocean", "The Neon Waves", "Synthscape", 231000, Uri.EMPTY),
                    Track(6, "Slow Burn", "Luna Echo", "Dreamland", 205000, Uri.EMPTY),
                    Track(7, "Voltage", "Static Wave", "Electric", 176000, Uri.EMPTY),
                    Track(8, "Hollow", "Astral Keys", "Polar", 220000, Uri.EMPTY)
                ))
            }

            withContext(Dispatchers.Main) {
                tracks.clear()
                tracks.addAll(loaded)
                updateNowPlaying()
                setupTrackList()
            }
        }
    }

    private fun setupTrackList() {
        binding.recyclerTracks.layoutManager = LinearLayoutManager(this)
        binding.recyclerTracks.adapter = TrackListAdapter(tracks) { track ->
            currentIndex = tracks.indexOf(track)
            playTrack(track)
        }
    }

    private fun togglePlayPause() {
        if (tracks.isEmpty()) return
        if (isPlaying) {
            mediaPlayer?.pause()
            isPlaying = false
            binding.btnPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            if (mediaPlayer == null) playTrack(tracks[currentIndex])
            else {
                mediaPlayer?.start()
                isPlaying = true
                binding.btnPlayPause.setImageResource(R.drawable.ic_pause)
                handler.post(updateSeekBar)
            }
        }
    }

    private fun playTrack(track: Track) {
        mediaPlayer?.release()
        if (track.uri != Uri.EMPTY) {
            try {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(applicationContext, track.uri)
                    prepare()
                    start()
                    setOnCompletionListener { playNext() }
                }
                binding.seekBar.max = mediaPlayer!!.duration
            } catch (e: Exception) {
                // Demo mode - just update UI
            }
        }
        isPlaying = true
        binding.btnPlayPause.setImageResource(R.drawable.ic_pause)
        updateNowPlaying()
        handler.post(updateSeekBar)
    }

    private fun playNext() {
        currentIndex = (currentIndex + 1) % tracks.size
        playTrack(tracks[currentIndex])
    }

    private fun playPrev() {
        currentIndex = if (currentIndex > 0) currentIndex - 1 else tracks.size - 1
        playTrack(tracks[currentIndex])
    }

    private fun toggleShuffle() {
        binding.btnShuffle.alpha = if (binding.btnShuffle.alpha == 1f) 0.4f else 1f
    }

    private fun toggleRepeat() {
        binding.btnRepeat.alpha = if (binding.btnRepeat.alpha == 1f) 0.4f else 1f
    }

    private fun updateNowPlaying() {
        if (tracks.isEmpty()) return
        val t = tracks[currentIndex]
        binding.tvTrackTitle.text = t.title
        binding.tvArtist.text = t.artist
        binding.tvAlbum.text = t.album
        binding.tvDuration.text = formatTime(t.duration)
        binding.seekBar.max = t.duration.toInt()
        binding.seekBar.progress = 0
        binding.tvCurrentTime.text = "0:00"
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        return "${s / 60}:${"%02d".format(s % 60)}"
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
    }
}
