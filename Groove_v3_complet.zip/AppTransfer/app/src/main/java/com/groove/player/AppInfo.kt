package com.groove.player

data class AppInfo(
    val name: String,
    val packageName: String,
    val apkPath: String,
    val sizeBytes: Long,
    val isSystemApp: Boolean,
    var isSelected: Boolean = false
)
