package com.groove.player

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.groove.player.databinding.ActivityAddSecureBinding
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddToSecureSpaceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddSecureBinding
    private val allApps = mutableListOf<AppInfo>()
    private val filteredApps = mutableListOf<AppInfo>()
    private lateinit var adapter: PickerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddSecureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }

        binding.searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterApps(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        adapter = PickerAdapter(filteredApps)
        binding.recyclerPicker.layoutManager = LinearLayoutManager(this)
        binding.recyclerPicker.adapter = adapter
        loadApps()
    }

    private fun loadApps() {
        binding.progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            val pm = packageManager
            val alreadySecure = SecureSpaceManager.getApps(this@AddToSecureSpaceActivity)
            val apps = pm.getInstalledPackages(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName }
                .mapNotNull { pkg ->
                    try {
                        val info = pkg.applicationInfo
                        AppInfo(
                            packageName = pkg.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            icon = pm.getApplicationIcon(info),
                            apkPath = info.sourceDir,
                            sizeMb = java.io.File(info.sourceDir).length() / (1024f * 1024f),
                            isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            isSelected = alreadySecure.contains(pkg.packageName)
                        )
                    } catch (e: Exception) { null }
                }
                .filter { !it.isSystemApp } // Only user apps by default
                .sortedWith(compareByDescending<AppInfo> { it.isSelected }.thenBy { it.appName })

            withContext(Dispatchers.Main) {
                allApps.clear()
                allApps.addAll(apps)
                filterApps("")
                binding.progressBar.visibility = View.GONE
            }
        }
    }

    private fun filterApps(query: String) {
        filteredApps.clear()
        filteredApps.addAll(
            if (query.isEmpty()) allApps
            else allApps.filter {
                it.appName.contains(query, ignoreCase = true) ||
                it.packageName.contains(query, ignoreCase = true)
            }
        )
        adapter.notifyDataSetChanged()
    }

    inner class PickerAdapter(
        private val apps: List<AppInfo>
    ) : RecyclerView.Adapter<PickerAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.imgPickerIcon)
            val name: TextView  = view.findViewById(R.id.tvPickerName)
            val size: TextView  = view.findViewById(R.id.tvPickerSize)
            val toggle: MaterialSwitch = view.findViewById(R.id.switchSecure)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_picker_secure, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = apps[position]
            holder.icon.setImageDrawable(app.icon)
            holder.name.text = app.appName
            holder.size.text = "%.1f MB".format(app.sizeMb)
            holder.toggle.setOnCheckedChangeListener(null)
            holder.toggle.isChecked = app.isSelected

            holder.toggle.setOnCheckedChangeListener { _, checked ->
                app.isSelected = checked
                if (checked) {
                    SecureSpaceManager.addApp(this@AddToSecureSpaceActivity, app.packageName)
                    Toast.makeText(this@AddToSecureSpaceActivity,
                        "${app.appName} ajouté à l'Espace Sécurisé", Toast.LENGTH_SHORT).show()
                } else {
                    SecureSpaceManager.removeApp(this@AddToSecureSpaceActivity, app.packageName)
                    Toast.makeText(this@AddToSecureSpaceActivity,
                        "${app.appName} retiré", Toast.LENGTH_SHORT).show()
                }
                notifyItemChanged(position)
            }

            holder.itemView.setOnClickListener {
                holder.toggle.isChecked = !holder.toggle.isChecked
            }

            holder.itemView.setBackgroundColor(
                if (app.isSelected)
                    resources.getColor(R.color.admin_granted_bg, null)
                else
                    resources.getColor(android.R.color.transparent, null)
            )
        }

        override fun getItemCount() = apps.size
    }
}
