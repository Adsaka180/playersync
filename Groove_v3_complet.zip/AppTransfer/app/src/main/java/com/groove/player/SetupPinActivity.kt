package com.groove.player

import android.content.Intent
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.groove.player.databinding.ActivitySetupPinBinding

class SetupPinActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupPinBinding

    enum class Step { ENTER, CONFIRM, HINT }

    private var step = Step.ENTER
    private var firstPin = ""
    private var currentInput = ""
    private val PIN_LENGTH = 4

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupPinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupKeypad()
        updateUI()
    }

    private fun setupKeypad() {
        val keys = listOf(
            binding.key0, binding.key1, binding.key2, binding.key3,
            binding.key4, binding.key5, binding.key6, binding.key7,
            binding.key8, binding.key9
        )
        keys.forEachIndexed { idx, btn ->
            btn.setOnClickListener { onKeyPress(idx.toString()) }
        }
        binding.keyDel.setOnClickListener { onDelete() }
        binding.btnSkipHint.setOnClickListener { saveAndFinish("") }
        binding.btnSaveHint.setOnClickListener {
            saveAndFinish(binding.etHint.text?.toString() ?: "")
        }
        binding.btnBack.setOnClickListener { onBackPressed() }
    }

    private fun onKeyPress(digit: String) {
        if (currentInput.length >= PIN_LENGTH) return
        currentInput += digit
        updateDots()
        if (currentInput.length == PIN_LENGTH) {
            when (step) {
                Step.ENTER -> {
                    firstPin = currentInput
                    currentInput = ""
                    step = Step.CONFIRM
                    updateUI()
                }
                Step.CONFIRM -> {
                    if (currentInput == firstPin) {
                        step = Step.HINT
                        updateUI()
                    } else {
                        shakeAndReset("Les codes ne correspondent pas")
                    }
                }
                Step.HINT -> {}
            }
        }
    }

    private fun onDelete() {
        if (currentInput.isNotEmpty()) {
            currentInput = currentInput.dropLast(1)
            updateDots()
        }
    }

    private fun updateDots() {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { i, dot ->
            dot.setBackgroundResource(
                if (i < currentInput.length) R.drawable.dot_filled else R.drawable.dot_empty
            )
        }
    }

    private fun updateUI() {
        when (step) {
            Step.ENTER -> {
                binding.tvTitle.text = "Créer un code"
                binding.tvSubtitle.text = "Ce code protègera votre Espace Sécurisé"
                binding.layoutKeypad.visibility = View.VISIBLE
                binding.layoutHint.visibility = View.GONE
                binding.dotsRow.visibility = View.VISIBLE
            }
            Step.CONFIRM -> {
                binding.tvTitle.text = "Confirmer le code"
                binding.tvSubtitle.text = "Saisissez à nouveau votre code"
                updateDots()
            }
            Step.HINT -> {
                binding.tvTitle.text = "Indice (optionnel)"
                binding.tvSubtitle.text = "Un indice pour vous souvenir de votre code"
                binding.layoutKeypad.visibility = View.GONE
                binding.dotsRow.visibility = View.GONE
                binding.layoutHint.visibility = View.VISIBLE
            }
        }
    }

    private fun shakeAndReset(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
        val vibrator = getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 80), -1))
        currentInput = ""
        updateDots()
        binding.dotsRow.postDelayed({ binding.tvError.visibility = View.GONE }, 1500)
    }

    private fun saveAndFinish(hint: String) {
        SecureSpaceManager.setupPin(this, firstPin, hint)
        startActivity(Intent(this, SecureSpaceActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        })
        finish()
    }

    override fun onBackPressed() {
        when (step) {
            Step.CONFIRM -> {
                step = Step.ENTER
                currentInput = ""
                firstPin = ""
                updateUI()
                updateDots()
            }
            else -> super.onBackPressed()
        }
    }
}
