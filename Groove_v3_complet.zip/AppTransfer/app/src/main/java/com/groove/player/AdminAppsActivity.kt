package com.groove.player

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.groove.player.databinding.ActivityAdminAppsBinding
import com.google.android.material.chip.Chip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AdminAppEntry(
    val packageName: String,
    val appName: String,
    val icon: Drawable,
    val isSystemApp: Boolean,
    var isAdminGranted: Boolean = false
)

class AdminAppsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminAppsBinding
    private lateinit var dpm: DevicePolicyManager
    private lateinit var adminComponent: ComponentName

    private val allApps = mutableListOf<AdminAppEntry>()
    private val filteredApps = mutableListOf<AdminAppEntry>()
    private lateinit var adapter: AdminAppAdapter

    // SharedPreferences key to persist our custom admin-granted list
    private val PREFS_NAME = "admin_apps_prefs"
    private val KEY_GRANTED = "granted_packages"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminAppsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = DeviceAdminManager.getAdminComponent(this)

        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupFilters()
        loadApps()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnInfo.setOnClickListener { showInfoDialog() }
    }

    private fun setupRecyclerView() {
        adapter = AdminAppAdapter(
            apps = filteredApps,
            onToggle = { app, granted -> onAdminToggle(app, granted) }
        )
        binding.recyclerAdminApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerAdminApps.adapter = adapter
    }

    private fun setupSearch() {
        binding.searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterApps(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupFilters() {
        binding.chipAll.setOnCheckedChangeListener { _, _ -> filterApps(binding.searchField.text?.toString() ?: "") }
        binding.chipGranted.setOnCheckedChangeListener { _, _ -> filterApps(binding.searchField.text?.toString() ?: "") }
        binding.chipUser.setOnCheckedChangeListener { _, _ -> filterApps(binding.searchField.text?.toString() ?: "") }
        binding.chipSystem.setOnCheckedChangeListener { _, _ -> filterApps(binding.searchField.text?.toString() ?: "") }
    }

    private fun loadApps() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerAdminApps.visibility = View.GONE

        CoroutineScope(Dispatchers.IO).launch {
            val pm = packageManager
            val grantedSet = getGrantedPackages()

            val apps = pm.getInstalledPackages(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName } // exclude self
                .mapNotNull { pkg ->
                    try {
                        val info = pkg.applicationInfo
                        AdminAppEntry(
                            packageName = pkg.packageName,
                            appName = pm.getApplicationLabel(info).toString(),
                            icon = pm.getApplicationIcon(info),
                            isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            isAdminGranted = grantedSet.contains(pkg.packageName)
                        )
                    } catch (e: Exception) { null }
                }
                .sortedWith(compareByDescending<AdminAppEntry> { it.isAdminGranted }.thenBy { it.appName })

            withContext(Dispatchers.Main) {
                allApps.clear()
                allApps.addAll(apps)
                filterApps("")
                binding.progressBar.visibility = View.GONE
                binding.recyclerAdminApps.visibility = View.VISIBLE
                updateStats()
            }
        }
    }

    private fun filterApps(query: String) {
        filteredApps.clear()
        filteredApps.addAll(allApps.filter { app ->
            val matchQuery = query.isEmpty() ||
                    app.appName.contains(query, ignoreCase = true) ||
                    app.packageName.contains(query, ignoreCase = true)
            val matchFilter = when {
                binding.chipGranted.isChecked -> app.isAdminGranted
                binding.chipUser.isChecked -> !app.isSystemApp
                binding.chipSystem.isChecked -> app.isSystemApp
                else -> true
            }
            matchQuery && matchFilter
        })
        adapter.notifyDataSetChanged()
    }

    private fun onAdminToggle(app: AdminAppEntry, grant: Boolean) {
        if (grant) {
            showGrantConfirmDialog(app)
        } else {
            showRevokeConfirmDialog(app)
        }
    }

    private fun showGrantConfirmDialog(app: AdminAppEntry) {
        AlertDialog.Builder(this)
            .setTitle("Ajouter aux apps admin")
            .setMessage(
                "Accorder les droits administrateur à :\n\n" +
                "📱 ${app.appName}\n" +
                "${app.packageName}\n\n" +
                "⚠️ Cette application pourra :\n" +
                "• Être prioritaire lors des transferts\n" +
                "• Bénéficier de la désinstallation automatique\n" +
                "• Être gérée par AppTransfer sans confirmation\n\n" +
                "Note : ceci n'accorde PAS de vrais droits système — c'est une liste interne à AppTransfer."
            )
            .setPositiveButton("Accorder") { _, _ ->
                app.isAdminGranted = true
                saveGrantedPackages()
                adapter.notifyDataSetChanged()
                updateStats()
                Toast.makeText(this, "${app.appName} ajouté aux apps admin", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler") { _, _ ->
                // Revert toggle
                adapter.notifyDataSetChanged()
            }
            .setCancelable(false)
            .show()
    }

    private fun showRevokeConfirmDialog(app: AdminAppEntry) {
        AlertDialog.Builder(this)
            .setTitle("Retirer les droits admin")
            .setMessage("Retirer les droits administrateur de ${app.appName} ?\n\nCette app ne bénéficiera plus de la gestion automatique lors des transferts.")
            .setPositiveButton("Retirer") { _, _ ->
                app.isAdminGranted = false
                saveGrantedPackages()
                adapter.notifyDataSetChanged()
                updateStats()
                Toast.makeText(this, "${app.appName} retiré des apps admin", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler") { _, _ ->
                adapter.notifyDataSetChanged()
            }
            .show()
    }

    private fun showInfoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Gestion Admin des apps")
            .setMessage(
                "Cette section vous permet d'ajouter n'importe quelle application à la liste des apps gérées par AppTransfer en mode Administrateur.\n\n" +
                "📋 Ce que ça change :\n" +
                "• Les apps listées ici seront prioritaires lors des transferts\n" +
                "• AppTransfer peut les désinstaller automatiquement après transfert (si mode admin actif)\n" +
                "• Aucune confirmation supplémentaire ne sera demandée\n\n" +
                "🔒 Important :\n" +
                "Il ne s'agit PAS de droits système réels — c'est uniquement la liste interne qu'AppTransfer utilise pour ses opérations. Vous pouvez ajouter ou retirer des apps à tout moment."
            )
            .setPositiveButton("Compris", null)
            .show()
    }

    private fun updateStats() {
        val grantedCount = allApps.count { it.isAdminGranted }
        val totalCount = allApps.size
        binding.tvStats.text = "$grantedCount app${if (grantedCount > 1) "s" else ""} avec droits admin sur $totalCount"
        binding.progressStats.max = totalCount
        binding.progressStats.progress = grantedCount
    }

    private fun getGrantedPackages(): Set<String> {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_GRANTED, emptySet()) ?: emptySet()
    }

    private fun saveGrantedPackages() {
        val granted = allApps.filter { it.isAdminGranted }.map { it.packageName }.toSet()
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_GRANTED, granted)
            .apply()
    }

    fun isPackageAdminGranted(context: Context, packageName: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val granted = prefs.getStringSet(KEY_GRANTED, emptySet()) ?: emptySet()
        return granted.contains(packageName)
    }

    // ── Adapter ──────────────────────────────────────────────────────────────

    inner class AdminAppAdapter(
        private val apps: List<AdminAppEntry>,
        private val onToggle: (AdminAppEntry, Boolean) -> Unit
    ) : RecyclerView.Adapter<AdminAppAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.imgAdminAppIcon)
            val name: TextView = view.findViewById(R.id.tvAdminAppName)
            val pkg: TextView = view.findViewById(R.id.tvAdminPackage)
            val badge: TextView = view.findViewById(R.id.tvSystemBadge)
            val toggle: com.google.android.material.materialswitch.MaterialSwitch = view.findViewById(R.id.switchAdminGrant)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_admin_app, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = apps[position]
            holder.icon.setImageDrawable(app.icon)
            holder.name.text = app.appName
            holder.pkg.text = app.packageName
            holder.badge.visibility = if (app.isSystemApp) View.VISIBLE else View.GONE

            // Prevent listener fire during bind
            holder.toggle.setOnCheckedChangeListener(null)
            holder.toggle.isChecked = app.isAdminGranted
            holder.toggle.setOnCheckedChangeListener { _, checked ->
                onToggle(app, checked)
            }

            holder.itemView.setBackgroundColor(
                if (app.isAdminGranted)
                    resources.getColor(R.color.admin_granted_bg, null)
                else
                    resources.getColor(android.R.color.transparent, null)
            )
        }

        override fun getItemCount() = apps.size
    }
}
