package com.groove.player

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.groove.player.databinding.ActivityVaultDashboardBinding

class VaultDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVaultDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVaultDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    private fun setupUI() {
        binding.btnClose.setOnClickListener { finish() }

        // ── 1. Espace Sécurisé ──────────────────────────────────────────────
        binding.cardSecureSpace.setOnClickListener {
            startActivity(Intent(this, SecureSpaceActivity::class.java))
        }

        // ── 2. Transfert d'applications ─────────────────────────────────────
        binding.cardTransfer.setOnClickListener {
            // Need permissions first
            val intent = Intent(this, PermissionsActivity::class.java)
            intent.putExtra("from_vault", true)
            startActivity(intent)
        }

        // ── 3. Gestion Admin (apps) ──────────────────────────────────────────
        binding.cardAdminApps.setOnClickListener {
            startActivity(Intent(this, AdminAppsActivity::class.java))
        }

        // ── 4. Mode Administrateur système ─────────────────────────────────
        binding.cardDeviceAdmin.setOnClickListener {
            val isAdmin = DeviceAdminManager.isAdminActive(this)
            if (isAdmin) {
                Toast.makeText(this, "Mode administrateur déjà actif ✓", Toast.LENGTH_SHORT).show()
            } else {
                DeviceAdminManager.requestAdminPrivileges(this, 1001)
            }
            updateAdminStatus()
        }

        // ── 5. Code PIN factice ─────────────────────────────────────────────
        binding.cardFakePin.setOnClickListener {
            startActivity(Intent(this, SetupPinActivity::class.java).apply {
                putExtra("mode", "fake")
            })
        }

        // ── 6. Paramètres de l'espace ───────────────────────────────────────
        binding.cardSpaceSettings.setOnClickListener {
            startActivity(Intent(this, SecureSpaceActivity::class.java).apply {
                putExtra("open_settings", true)
            })
        }

        updateAdminStatus()
        updateSecureSpaceStatus()
    }

    override fun onResume() {
        super.onResume()
        updateAdminStatus()
        updateSecureSpaceStatus()
    }

    private fun updateAdminStatus() {
        val isAdmin = DeviceAdminManager.isAdminActive(this)
        binding.tvAdminStatus.text = if (isAdmin) "Actif ✓" else "Inactif — appuyez pour activer"
        binding.tvAdminStatus.setTextColor(
            getColor(if (isAdmin) R.color.green_500 else R.color.orange_500)
        )
        binding.ivAdminDot.setBackgroundResource(
            if (isAdmin) R.drawable.dot_green else R.drawable.dot_orange
        )
    }

    private fun updateSecureSpaceStatus() {
        val isSetup = SecureSpaceManager.isSetup(this)
        val appsCount = SecureSpaceManager.getApps(this).size
        binding.tvSecureStatus.text = if (isSetup) "$appsCount app(s) protégée(s)" else "Non configuré"
        binding.ivSecureDot.setBackgroundResource(
            if (isSetup) R.drawable.dot_green else R.drawable.dot_orange
        )
    }
}
