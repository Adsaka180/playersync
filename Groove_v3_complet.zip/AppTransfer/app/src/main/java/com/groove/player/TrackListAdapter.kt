package com.groove.player

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrackListAdapter(
    private val tracks: List<Track>,
    private val onClick: (Track) -> Unit
) : RecyclerView.Adapter<TrackListAdapter.VH>() {

    private var activeIndex = 0

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTrackItemTitle)
        val tvArtist: TextView = view.findViewById(R.id.tvTrackItemArtist)
        val tvDuration: TextView = view.findViewById(R.id.tvTrackItemDuration)
        val tvNumber: TextView = view.findViewById(R.id.tvTrackNumber)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_track, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val track = tracks[position]
        holder.tvTitle.text = track.title
        holder.tvArtist.text = "${track.artist} • ${track.album}"
        holder.tvNumber.text = "${position + 1}"

        val ms = track.duration
        val s = ms / 1000
        holder.tvDuration.text = "${s / 60}:${"%02d".format(s % 60)}"

        val isActive = position == activeIndex
        holder.tvTitle.setTextColor(
            holder.itemView.context.getColor(
                if (isActive) R.color.groove_accent else R.color.groove_text_primary
            )
        )
        holder.itemView.setBackgroundColor(
            holder.itemView.context.getColor(
                if (isActive) R.color.groove_active_bg else android.R.color.transparent
            )
        )

        holder.itemView.setOnClickListener {
            val prev = activeIndex
            activeIndex = position
            notifyItemChanged(prev)
            notifyItemChanged(position)
            onClick(track)
        }
    }

    override fun getItemCount() = tracks.size
}
