package com.groove.player

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat

class PermissionItemView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val ivIcon: ImageView
    private val tvTitle: TextView
    private val tvDesc: TextView
    private val ivStatus: ImageView
    private var granted = false

    init {
        LayoutInflater.from(context).inflate(R.layout.view_permission_item, this, true)
        ivIcon = findViewById(R.id.ivPermIcon)
        tvTitle = findViewById(R.id.tvPermTitle)
        tvDesc = findViewById(R.id.tvPermDesc)
        ivStatus = findViewById(R.id.ivPermStatus)

        attrs?.let {
            val ta = context.obtainStyledAttributes(it, R.styleable.PermissionItemView)
            tvTitle.text = ta.getString(R.styleable.PermissionItemView_permTitle) ?: ""
            tvDesc.text = ta.getString(R.styleable.PermissionItemView_permDesc) ?: ""
            val iconRes = ta.getResourceId(R.styleable.PermissionItemView_permIcon, 0)
            if (iconRes != 0) ivIcon.setImageResource(iconRes)
            ta.recycle()
        }
    }

    fun setGranted(isGranted: Boolean) {
        granted = isGranted
        if (isGranted) {
            ivStatus.setImageResource(R.drawable.ic_check_circle)
            ivStatus.setColorFilter(ContextCompat.getColor(context, R.color.green_500))
            alpha = 1f
        } else {
            ivStatus.setImageResource(R.drawable.ic_pending)
            ivStatus.setColorFilter(ContextCompat.getColor(context, R.color.orange_500))
            alpha = 0.8f
        }
    }

    fun isGranted() = granted
}
