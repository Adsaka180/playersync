package com.groove.player

import android.content.Intent
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.groove.player.databinding.ActivityPinUnlockBinding

class PinUnlockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinUnlockBinding
    private var currentInput = ""
    private var attempts = 0
    private val PIN_LENGTH = 4
    private val MAX_ATTEMPTS = 5

    // Where to go after successful unlock
    private lateinit var destination: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinUnlockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        destination = intent.getStringExtra("destination") ?: "secure_space"

        setupKeypad()
        setupBiometric()
        updateDots()

        binding.tvHint.text = SecureSpaceManager.getHint(this).let {
            if (it.isNotEmpty()) "Indice : $it" else ""
        }
        binding.btnClose.setOnClickListener { finish() }
    }

    private fun setupKeypad() {
        val keys = listOf(
            binding.key0, binding.key1, binding.key2, binding.key3,
            binding.key4, binding.key5, binding.key6, binding.key7,
            binding.key8, binding.key9
        )
        keys.forEachIndexed { idx, btn ->
            btn.setOnClickListener { onKeyPress(idx.toString()) }
        }
        binding.keyDel.setOnClickListener { onDelete() }
    }

    private fun setupBiometric() {
        if (!SecureSpaceManager.isBiometricEnabled(this)) {
            binding.btnBiometric.visibility = View.GONE
            return
        }
        val mgr = BiometricManager.from(this)
        val can = mgr.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        if (can == BiometricManager.BIOMETRIC_SUCCESS) {
            binding.btnBiometric.visibility = View.VISIBLE
            binding.btnBiometric.setOnClickListener { showBiometricPrompt() }
            showBiometricPrompt()
        } else {
            binding.btnBiometric.visibility = View.GONE
        }
    }

    private fun showBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = unlockAndRoute()
            override fun onAuthenticationFailed() {
                binding.tvError.text = "Empreinte non reconnue"
                binding.tvError.visibility = View.VISIBLE
            }
        }
        BiometricPrompt(this, executor, cb).authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Coffre Groove")
                .setSubtitle("Utilisez votre empreinte pour déverrouiller")
                .setNegativeButtonText("Utiliser le code")
                .build()
        )
    }

    private fun onKeyPress(digit: String) {
        if (currentInput.length >= PIN_LENGTH) return
        currentInput += digit
        updateDots()
        binding.tvError.visibility = View.GONE
        if (currentInput.length == PIN_LENGTH) verifyPin()
    }

    private fun onDelete() {
        if (currentInput.isNotEmpty()) {
            currentInput = currentInput.dropLast(1)
            updateDots()
        }
    }

    private fun verifyPin() {
        when (SecureSpaceManager.verifyPin(this, currentInput)) {
            SecureSpaceManager.PinResult.CORRECT -> unlockAndRoute()
            SecureSpaceManager.PinResult.FAKE    -> openFakeSpace()
            SecureSpaceManager.PinResult.WRONG   -> onWrongPin()
        }
    }

    private fun unlockAndRoute() {
        val intent = when (destination) {
            "vault_dashboard" -> Intent(this, VaultDashboardActivity::class.java)
            else              -> Intent(this, SecureSpaceActivity::class.java).apply {
                putExtra("unlocked", true)
            }
        }
        startActivity(intent)
        finish()
    }

    private fun openFakeSpace() {
        startActivity(Intent(this, SecureSpaceActivity::class.java).apply {
            putExtra("unlocked", true)
            putExtra("fake_mode", true)
        })
        finish()
    }

    private fun onWrongPin() {
        attempts++
        currentInput = ""
        updateDots()
        val remaining = MAX_ATTEMPTS - attempts
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0,100,80,100,80,100), -1))
        } catch (_: Exception) {}

        if (attempts >= MAX_ATTEMPTS) {
            binding.tvError.text = "Trop de tentatives — réessayez dans 30s"
            binding.tvError.visibility = View.VISIBLE
            disableKeypadTemporarily()
        } else {
            binding.tvError.text = "Code incorrect ($remaining essai${if(remaining>1)"s" else ""} restant${if(remaining>1)"s" else ""})"
            binding.tvError.visibility = View.VISIBLE
        }
    }

    private fun disableKeypadTemporarily() {
        val keys = listOf(binding.key0,binding.key1,binding.key2,binding.key3,
            binding.key4,binding.key5,binding.key6,binding.key7,
            binding.key8,binding.key9,binding.keyDel)
        keys.forEach { it.isEnabled = false }
        binding.root.postDelayed({
            keys.forEach { it.isEnabled = true }
            attempts = 0
            binding.tvError.visibility = View.GONE
        }, 30_000)
    }

    private fun updateDots() {
        listOf(binding.dot1,binding.dot2,binding.dot3,binding.dot4).forEachIndexed { i, dot ->
            dot.setBackgroundResource(if(i < currentInput.length) R.drawable.dot_filled else R.drawable.dot_empty)
        }
    }
}
