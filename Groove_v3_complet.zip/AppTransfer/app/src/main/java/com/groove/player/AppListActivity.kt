package com.groove.player

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.groove.player.databinding.ActivityAppListBinding
import com.google.android.material.checkbox.MaterialCheckBox
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppListBinding
    private val allApps = mutableListOf<AppInfo>()
    private val filteredApps = mutableListOf<AppInfo>()
    private lateinit var adapter: AppAdapter
    private var showSystemApps = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupSearchBar()
        setupFilterButton()
        setupTransferButton()
        setupSecureSpaceButton()
        loadApps()
    }

    private fun setupSecureSpaceButton() {
        binding.btnSecureSpace.setOnClickListener {
            val intent = if (SecureSpaceManager.isSetup(this)) {
                Intent(this, PinUnlockActivity::class.java)
            } else {
                Intent(this, SetupPinActivity::class.java)
            }
            startActivity(intent)
        }
    }

    private fun setupRecyclerView() {
        adapter = AppAdapter(filteredApps) { app, selected ->
            app.isSelected = selected
            updateTransferButton()
        }
        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter
    }

    private fun setupSearchBar() {
        binding.searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filterApps(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupFilterButton() {
        binding.btnToggleSystem.setOnClickListener {
            showSystemApps = !showSystemApps
            binding.btnToggleSystem.text = if (showSystemApps) "Masquer système" else "Apps système"
            filterApps(binding.searchField.text?.toString() ?: "")
        }
    }

    private fun setupTransferButton() {
        binding.btnTransfer.setOnClickListener {
            val selectedApps = allApps.filter { it.isSelected }
            if (selectedApps.isEmpty()) return@setOnClickListener
            startActivity(Intent(this, TransferActivity::class.java).apply {
                putStringArrayListExtra("selected_packages", ArrayList(selectedApps.map { it.packageName }))
            })
        }
    }

    private fun loadApps() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerApps.visibility = View.GONE

        CoroutineScope(Dispatchers.IO).launch {
            val pm = packageManager
            val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)
            val apps = packages.mapNotNull { pkg ->
                try {
                    val info = pkg.applicationInfo
                    val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    AppInfo(
                        packageName = pkg.packageName,
                        appName = pm.getApplicationLabel(info).toString(),
                        icon = pm.getApplicationIcon(info),
                        apkPath = info.sourceDir,
                        sizeMb = java.io.File(info.sourceDir).length() / (1024f * 1024f),
                        isSystemApp = isSystem
                    )
                } catch (e: Exception) { null }
            }.sortedBy { it.appName }

            withContext(Dispatchers.Main) {
                allApps.clear(); allApps.addAll(apps)
                filterApps("")
                binding.progressBar.visibility = View.GONE
                binding.recyclerApps.visibility = View.VISIBLE
                binding.tvAppCount.text = "${allApps.count { !it.isSystemApp }} applications utilisateur"
            }
        }
    }

    private fun filterApps(query: String) {
        filteredApps.clear()
        filteredApps.addAll(allApps.filter { app ->
            val mq = query.isEmpty() || app.appName.contains(query, ignoreCase = true) || app.packageName.contains(query, ignoreCase = true)
            val mf = showSystemApps || !app.isSystemApp
            mq && mf
        })
        adapter.notifyDataSetChanged()
    }

    private fun updateTransferButton() {
        val count = allApps.count { it.isSelected }
        binding.btnTransfer.apply {
            isEnabled = count > 0
            text = if (count > 0) "Transférer $count app${if(count>1)"s" else ""}" else "Sélectionner des apps"
        }
    }

    inner class AppAdapter(
        private val apps: List<AppInfo>,
        private val onSelectionChanged: (AppInfo, Boolean) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.imgAppIcon)
            val name: TextView = view.findViewById(R.id.tvAppName)
            val pkg: TextView = view.findViewById(R.id.tvPackageName)
            val size: TextView = view.findViewById(R.id.tvAppSize)
            val checkbox: MaterialCheckBox = view.findViewById(R.id.checkApp)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = apps[position]
            holder.icon.setImageDrawable(app.icon)
            holder.name.text = app.appName
            holder.pkg.text = app.packageName
            holder.size.text = "%.1f MB".format(app.sizeMb)
            holder.checkbox.isChecked = app.isSelected
            holder.itemView.setOnClickListener {
                app.isSelected = !app.isSelected
                holder.checkbox.isChecked = app.isSelected
                onSelectionChanged(app, app.isSelected)
            }
            holder.checkbox.setOnCheckedChangeListener { _, checked ->
                app.isSelected = checked
                onSelectionChanged(app, checked)
            }
        }

        override fun getItemCount() = apps.size
    }
}
